import java.util.*;

/**
 * A GrammarSolver can generate expressions with valid grammar given a set of
 * grammar rules in Backus-Naur Form (BNF). The list of symbols representing
 * grammar can be retrieved and checked against.
 *
 * @author Jevin Gu
 * @class CSE 143 DK with Hunter Schafer
 * @assignment Programming Assignment #5
 * @duedate 2019-10-31 11:30pm
 */
public class GrammarSolver {

    private SortedMap<String, String[]> grammar; // nonterminals -> terminals

    /**
     * Instantiates grammar solver with a list of BNF format grammar rules.
     *
     * @param rules list of BNF rules to be parsed
     */
    public GrammarSolver(List<String> rules) {
        if (rules.isEmpty()) {
            throw new IllegalArgumentException();
        }
        this.grammar = new TreeMap<>();
        for (String rule : rules) {
            String[] termNonTerm = rule.split("::=");
            String nonTerminal = termNonTerm[0].trim();

            if (this.grammarContains(nonTerminal)) {
                throw new IllegalArgumentException();
            }

            String[] terminals = termNonTerm[1].split("\\|");
            for (int i = 0; i < terminals.length; i++) {
                terminals[i] = terminals[i].trim();
            }
            this.grammar.put(nonTerminal, terminals);
        }
    }

    /**
     * Prints out all non-terminals in grammar
     *
     * @return String of non-terminals in comma-separated format and surrounded
     * by brackets.
     */
    public String getSymbols() {
        return this.grammar.keySet().toString();
    }

    /**
     * Checks whether grammar contains a non-terminal
     *
     * @return boolean whether non-terminal exists
     */
    public boolean grammarContains(String symbol) {
        return this.grammar.containsKey(symbol);
    }

    /**
     * Generates a valid grammar a number of times given a valid non-terminal
     * and a number.
     *
     * @param symbol a valid non-terminal in the language. Returns
     *               IllegalArgumentException otherwise.
     * @param times  a non-negative. Returns IllegalArgumentException otherwise
     * @return String array of valid grammars which follow the non-terminal
     * symbol given.
     */
    public String[] generate(String symbol, int times) {
        if (times < 0 || !this.grammarContains(symbol)) {
            throw new IllegalArgumentException();
        }
        String[] generated = new String[times];

        for (int i = 0; i < times; i++) {
            generated[i] = generate(symbol);
        }
        return generated;
    }

    /**
     * Recursive helper method to generate grammar based on a string token.
     *
     * @param symbol accepts both non-terminals and terminals strings.
     * @return A string which follows the grammar rule represented by the
     * symbol, otherwise returns back the token if it is not a grammar rule.
     */
    private String generate(String symbol) {
        String[] terminal = this.grammar.get(symbol);
        if (terminal == null) {
            return symbol;
        }
        String randTerm = terminal[(int) (Math.random() * terminal.length)];
        String combine = "";
        for (String s : randTerm.split("\\s+")) {
            combine += generate(s) + " ";
        }
        return combine.trim();
    }
}
